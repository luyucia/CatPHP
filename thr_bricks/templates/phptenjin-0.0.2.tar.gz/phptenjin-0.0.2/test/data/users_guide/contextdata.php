$items = array('<FOO>', '&BAR', '"BAZ"');
$webmaster_email = 'webmaster@example.com';
$menu = array(
          array('name'=>'Top',   'url'=>'/'),
          array('name'=>'Products',   'url'=>'/prod'),
          array('name'=>'Support',   'url'=>'/support'),
        );
