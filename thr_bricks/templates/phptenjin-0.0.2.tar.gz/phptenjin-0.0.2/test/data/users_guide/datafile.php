$text  =  "foo";
$num   =  3.14;
$flag  =  true;
$items =  array("foo", "bar", "baz");
$hash  =  array('x'=>1, 'y'=>2);
